# MAVTINO X — Frontend MVP (React + Vite)

This zip contains a front-end MVP for MAVTINO X (Facebook-style feed + WhatsApp-style chats) built with React, Vite, Tailwind, Framer Motion and Lucide icons.

## How to run locally

1. Extract the zip and `cd` into the project folder:
```bash
npm install
npm run dev
```

2. Open the local dev URL printed by Vite (usually http://localhost:5173).

## Deploying to GitHub Pages / Vercel

- For quick deployment I recommend Vercel: connect your GitHub repo to Vercel and it will deploy automatically.
- If using GitHub Pages, you may need to build and push the `dist` folder or use `gh-pages` package.

## Notes

- This is a **frontend-only** demo. Messages and posts are mocked in memory. For real chat and persistence you'll need a backend (WebSocket or real-time DB) and auth (phone/email).
- Tailwind classes are used. Tailwind is configured in `tailwind.config.js` already present in the repo.


## Firebase setup (required to enable full features)

1. Go to https://console.firebase.google.com/ and create a new project (e.g. `mavtino-x`).
2. In Project Settings, register a web app and copy the Firebase config. Replace the placeholders in `src/firebase.js`.
3. In **Authentication** -> **Sign-in method**, enable **Email/Password** and **Phone** (for Phone you must also set up reCAPTCHA domain verification).
4. In **Firestore Database**, create a database (start in test mode for development) and allow reads/writes while testing.
5. In **Storage**, create a bucket (default created). Configure rules for uploads if needed.
6. Install deps and run locally:
```bash
npm install
npm run dev
```
7. For deployment, you can deploy to Firebase Hosting (`firebase init`, `firebase deploy`) or use Vercel (connect GitHub repo).

Notes about Phone Auth: Phone sign-in requires a working reCAPTCHA on the domain where the app is hosted. When running locally, Firebase may allow test phone numbers in Authentication -> Sign-in method -> Phone -> Add test phone number.
