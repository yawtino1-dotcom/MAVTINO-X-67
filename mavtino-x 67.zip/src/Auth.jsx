import React, { useState, useEffect } from 'react';
import { auth } from './firebase';
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  RecaptchaVerifier,
  signInWithPhoneNumber
} from 'firebase/auth';

export function useAuth() {
  const [user, setUser] = useState(null);
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (u) => setUser(u));
    return () => unsub();
  }, []);
  return user;
}

export function EmailAuth({ onError }) {
  const [mode, setMode] = useState('signin'); // or signup
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  async function submit(e) {
    e.preventDefault();
    try {
      if (mode === 'signup') {
        await createUserWithEmailAndPassword(auth, email, password);
      } else {
        await signInWithEmailAndPassword(auth, email, password);
      }
    } catch (err) {
      onError?.(err);
    }
  }

  return (
    <form onSubmit={submit} className="space-y-2">
      <div className="text-sm">Email</div>
      <input className="w-full p-2 rounded" value={email} onChange={e=>setEmail(e.target.value)} />
      <div className="text-sm">Password</div>
      <input type="password" className="w-full p-2 rounded" value={password} onChange={e=>setPassword(e.target.value)} />
      <div className="flex gap-2">
        <button type="submit" className="px-3 py-2 rounded" style={{background:'#D4AF37'}}> {mode==='signup'?'Sign up':'Sign in'}</button>
        <button type="button" onClick={()=>setMode(mode==='signup'?'signin':'signup')} className="px-3 py-2 rounded border">Switch</button>
      </div>
    </form>
  );
}

// Phone auth requires reCAPTCHA and phone number verification.
// This component provides a simple flow but you must enable Phone Auth in Firebase console.
export function PhoneAuth({ onError }) {
  const [phone, setPhone] = useState('');
  const [code, setCode] = useState('');
  const [confirmation, setConfirmation] = useState(null);

  function setupRecaptcha() {
    if (window.recaptchaVerifier) return window.recaptchaVerifier;
    window.recaptchaVerifier = new RecaptchaVerifier('recaptcha-container', {
      size: 'invisible'
    }, auth);
    return window.recaptchaVerifier;
  }

  async function sendCode(e) {
    e.preventDefault();
    try {
      const verifier = setupRecaptcha();
      const confirmationResult = await signInWithPhoneNumber(auth, phone, verifier);
      setConfirmation(confirmationResult);
    } catch (err) {
      onError?.(err);
    }
  }

  async function verifyCode(e) {
    e.preventDefault();
    try {
      await confirmation.confirm(code);
    } catch (err) {
      onError?.(err);
    }
  }

  return (
    <div className="space-y-2">
      <div id="recaptcha-container"></div>
      {!confirmation ? (
        <form onSubmit={sendCode} className="space-y-2">
          <div>Phone (E.164 format) e.g. +233xxxxxxxxx</div>
          <input value={phone} onChange={e=>setPhone(e.target.value)} className="w-full p-2 rounded" />
          <button className="px-3 py-2 rounded" style={{background:'#D4AF37'}}>Send code</button>
        </form>
      ) : (
        <form onSubmit={verifyCode} className="space-y-2">
          <div>Enter verification code</div>
          <input value={code} onChange={e=>setCode(e.target.value)} className="w-full p-2 rounded" />
          <button className="px-3 py-2 rounded" style={{background:'#D4AF37'}}>Verify</button>
        </form>
      )}
    </div>
  );
}

export function SignOutButton() {
  return <button className="px-3 py-2 rounded border" onClick={()=>signOut(auth)}>Sign out</button>;
}