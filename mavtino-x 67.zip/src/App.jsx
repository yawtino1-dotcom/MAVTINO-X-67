import React, { useMemo, useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Home,
  MessageCircle,
  Users,
  Bell,
  Search,
  Plus,
  Send,
  Phone,
  Video,
  EllipsisVertical,
  ThumbsUp,
  MessageSquare,
  Share2,
  LogOut,
  Settings,
  Image as ImageIcon
} from "lucide-react";

import { auth, db, storage } from "./firebase";
import { useAuth, EmailAuth, PhoneAuth, SignOutButton } from "./Auth";

import {
  collection,
  addDoc,
  query,
  orderBy,
  onSnapshot,
  serverTimestamp,
  doc,
  setDoc
} from "firebase/firestore";

import { ref, uploadBytesResumable, getDownloadURL } from "firebase/storage";

const COLORS = {
  bg: "#0b0b0c",
  panel: "#111113",
  border: "#1b1b1e",
  gold: "#D4AF37",
  goldSoft: "#E3C766",
  text: "#F8F8F8",
  textMuted: "#bdbdbf",
};

function Logo() {
  return (
    <div className="flex items-center gap-2">
      <div
        className="size-9 rounded-2xl"
        style={{
          background: `linear-gradient(135deg, ${COLORS.gold} 0%, ${COLORS.goldSoft} 40%, ${COLORS.gold} 100%)`,
          boxShadow: "0 0 24px rgba(212,175,55,0.25)",
        }}
      />
      <div className="font-extrabold tracking-wide">
        <span style={{ color: COLORS.text }}>MAVTINO</span>{" "}
        <span style={{ color: COLORS.gold }}>X</span>
      </div>
    </div>
  );
}

function PostCard({ post }) {
  return (
    <motion.article
      layout
      className="rounded-3xl overflow-hidden"
      style={{ border: `1px solid ${COLORS.border}`, background: COLORS.panel }}
    >
      <div className="p-4 flex items-center gap-3">
        <img src={post.authorPhoto || 'https://i.pravatar.cc/100?img=1'} className="size-10 rounded-full" />
        <div className="leading-tight">
          <div className="font-semibold" style={{ color: COLORS.text }}>
            {post.authorName || 'Unknown'}
          </div>
          <div className="text-xs" style={{ color: COLORS.textMuted }}>{post.createdAt?.toDate ? new Date(post.createdAt.seconds*1000).toLocaleString() : post.time}</div>
        </div>
      </div>
      <div className="px-4 pb-3" style={{ color: COLORS.text }}>{post.text}</div>
      {post.image && (
        <div className="aspect-[16/9] w-full overflow-hidden">
          <img src={post.image} className="w-full h-full object-cover" />
        </div>
      )}
      <div className="p-4 flex items-center gap-6 text-sm" style={{ color: COLORS.textMuted }}>
        <div className="flex items-center gap-2"><ThumbsUp size={18}/> {post.likes || 0}</div>
        <div className="flex items-center gap-2"><MessageSquare size={18}/> {post.comments || 0}</div>
        <div className="flex items-center gap-2"><Share2 size={18}/> Share</div>
      </div>
    </motion.article>
  );
}

export default function App() {
  const user = useAuth();
  const [tab, setTab] = useState("home");
  const [posts, setPosts] = useState([]);
  const [newPostText, setNewPostText] = useState("");
  const [uploading, setUploading] = useState(false);

  useEffect(()=>{
    // subscribe to posts collection
    const q = query(collection(db, 'posts'), orderBy('createdAt', 'desc'));
    const unsub = onSnapshot(q, (snap) => {
      const arr = snap.docs.map(d=>({ id: d.id, ...d.data() }));
      setPosts(arr);
    });
    return ()=>unsub();
  },[]);

  async function createPost(e){
    e?.preventDefault?.();
    if(!user){ alert('Please sign in'); return; }
    const data = {
      text: newPostText,
      authorName: user.displayName || user.email || user.phoneNumber || 'User',
      authorPhoto: user.photoURL || null,
      createdAt: serverTimestamp(),
    };
    setNewPostText('');
    try{
      await addDoc(collection(db,'posts'), data);
    }catch(err){
      console.error(err);
      alert('Failed to create post');
    }
  }

  return (
    <div className="min-h-screen" style={{ background: COLORS.bg }}>
      <header className="sticky top-0 z-40" style={{ borderBottom: `1px solid ${COLORS.border}` }}>
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <Logo />
          <div className="hidden md:flex items-center gap-2 flex-1 max-w-xl mx-6">
            <div className="flex items-center gap-2 flex-1 px-3 py-2 rounded-2xl"
                 style={{ background: "#0f0f12", border: `1px solid ${COLORS.border}` }}>
              <Search size={18} color={COLORS.textMuted} />
              <input placeholder="Search MAVTINO X" className="bg-transparent outline-none text-sm flex-1" style={{ color: COLORS.text }} />
            </div>
            <button className="px-3 py-2 rounded-2xl text-sm flex items-center gap-2"
                    style={{ border: `1px solid ${COLORS.gold}`, color: COLORS.gold }}>
              <Plus size={16}/> Create
            </button>
          </div>
          <div className="flex items-center gap-3">
            <div className="relative">
              <Bell color={COLORS.gold} />
              <span className="absolute -top-1 -right-1 text-[10px] px-1.5 rounded-xl" style={{ background: COLORS.gold, color: COLORS.bg }}>3</span>
            </div>
            {user ? (
              <>
                <img src={user.photoURL || 'https://i.pravatar.cc/100?img=22'} className="size-9 rounded-full" />
                <SignOutButton />
              </>
            ) : (
              <div className="flex items-center gap-2">
                <div style={{color:COLORS.text}} className="text-sm">Not signed in</div>
              </div>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        <aside className="lg:col-span-2 space-y-2">
          <button onClick={()=>setTab('home')} className="w-full p-3 rounded-2xl text-left" style={{border:`1px solid ${COLORS.border}`, background:'#0f0f12', color:COLORS.text}}>Home</button>
          <button onClick={()=>setTab('chats')} className="w-full p-3 rounded-2xl text-left" style={{border:`1px solid ${COLORS.border}`, background:'#0f0f12', color:COLORS.text}}>Chats</button>
          <button onClick={()=>setTab('groups')} className="w-full p-3 rounded-2xl text-left" style={{border:`1px solid ${COLORS.border}`, background:'#0f0f12', color:COLORS.text}}>Groups</button>
        </aside>

        <section className="lg:col-span-7">
          {tab==='home' && (
            <div>
              {user ? (
                <form onSubmit={createPost} className="p-4 rounded-3xl mb-4" style={{ border: `1px solid ${COLORS.border}`, background: COLORS.panel }}>
                  <div className="flex gap-3">
                    <img src={user.photoURL || 'https://i.pravatar.cc/100?img=22'} className="w-12 h-12 rounded-full" />
                    <textarea value={newPostText} onChange={e=>setNewPostText(e.target.value)} placeholder="What's on your mind?" className="flex-1 bg-transparent outline-none p-2" style={{color:COLORS.text}} />
                  </div>
                  <div className="mt-3 flex justify-end gap-2">
                    <button className="px-4 py-2 rounded-2xl" style={{background:`linear-gradient(135deg, ${COLORS.gold} 0%, ${COLORS.goldSoft} 60%, ${COLORS.gold} 100%)`}}>Post</button>
                  </div>
                </form>
              ) : (
                <div className="p-4 rounded-3xl mb-4" style={{ border: `1px solid ${COLORS.border}`, background: COLORS.panel }}>
                  <div style={{color:COLORS.text}}>Sign in to post and chat.</div>
                  <div className="mt-3 flex gap-2">
                    <EmailAuth onError={(e)=>alert(e.message)} />
                    <div style={{width:20}} />
                    <PhoneAuth onError={(e)=>alert(e.message)} />
                  </div>
                </div>
              )}

              <div className="space-y-4">
                {posts.map(p=> <PostCard key={p.id} post={p} />)}
              </div>
            </div>
          )}

          {tab==='chats' && (
            <div className="p-4 rounded-3xl" style={{ border: `1px solid ${COLORS.border}`, background: COLORS.panel }}>
              <div style={{color:COLORS.text}}>Chats will appear here — one-to-one and groups backed by Firestore.</div>
            </div>
          )}

          {tab==='groups' && (
            <div className="p-4 rounded-3xl" style={{ border: `1px solid ${COLORS.border}`, background: COLORS.panel }}>
              <div style={{color:COLORS.text}}>Groups coming soon.</div>
            </div>
          )}
        </section>

        <aside className="lg:col-span-3">
          <div className="p-4 rounded-3xl mb-4" style={{ border: `1px solid ${COLORS.border}`, background: COLORS.panel }}>
            <div style={{color:COLORS.text}} className="font-semibold mb-3">Account</div>
            {user ? (
              <div>
                <div style={{color:COLORS.text}}>Hello, {user.displayName || user.email || user.phoneNumber}</div>
                <div className="mt-3"><SignOutButton /></div>
              </div>
            ) : (
              <div>
                <div style={{color:COLORS.textMuted}}>Sign in with Email or Phone to enable posting and chatting.</div>
                <div className="mt-3">
                  <EmailAuth onError={(e)=>alert(e.message)} />
                </div>
              </div>
            )}
          </div>

          <div className="p-4 rounded-3xl" style={{ border: `1px solid ${COLORS.border}`, background: COLORS.panel }}>
            <div style={{color:COLORS.text}} className="font-semibold mb-1">Brand Palette</div>
            <div style={{color:COLORS.textMuted}} className="text-xs mb-3">Gold + Black, elegant and bold.</div>
            <div className="grid grid-cols-4 gap-2">
              <div className="h-10 rounded-xl" style={{background:COLORS.gold}}></div>
              <div className="h-10 rounded-xl" style={{background:COLORS.goldSoft}}></div>
              <div className="h-10 rounded-xl" style={{background:COLORS.panel}}></div>
              <div className="h-10 rounded-xl" style={{background:COLORS.bg}}></div>
            </div>
          </div>
        </aside>
      </main>

      <footer className="py-10 text-center text-xs" style={{ color: COLORS.textMuted }}>
        © {new Date().getFullYear()} MAVTINO X — Built as an MVP demo UI. Backed by Firebase for auth & realtime.
      </footer>
    </div>
  );
}